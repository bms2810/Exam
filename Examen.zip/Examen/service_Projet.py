import requests
from flask import Flask, request, jsonify
import sqlite3
from flask_cors import CORS
from flasgger import swag_from, Swagger

from mod_dao import enregistrer_projet

app = Flask(__name__)
app.config['SWAGGER']={
    'title': 'Gestion de projets',
    'version':1.1
}

# Activez CORS pour votre application
CORS(app)

# Endpoint pour créer un nouveau projet
@app.route('/projets', methods=['POST'])
def creer_projet():
    data = request.json

    # Récupérez les données du JSON
    code_projet = data.get('code')
    description = data.get('description')

    # Appelez la fonction du service DAO pour enregistrer les données
    enregistrer_projet(code_projet, description)

    return jsonify({"message": "Projet créé avec succès"})


# Endpoint pour lister tous les projets
@app.route('/projets', methods=['GET'])
@swag_from('get_projet.yml')
def lister_projets():
    try:
        conn = sqlite3.connect('projet.db')
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM projet')
        data = cursor.fetchall()
        conn.close()
        # Convertir les données en une liste de dictionnaires
        data_list = []
        for row in data:
            data_dict = {
                'id': row[0],
                'code': row[1],
                'description': row[2]
            }
            data_list.append(data_dict)

        return jsonify(data_list)
    except Exception as e:
        return jsonify({"error": str(e)}), 500
if __name__ == "__main__":
    swagger = Swagger(app)
    app.run(debug=True, port=5000)
