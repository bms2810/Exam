from flask import Flask, request, jsonify
from flask_cors import CORS
import sqlite3
app = Flask(__name__)
CORS(app, resources={r"/projets": {"origins": "http://localhost:5000"}})

# Endpoint pour créer un projet
@app.route('/projets', methods=['POST'])
def enregistrer_projet(code_projet, description):
    # Enregistrer les données dans la base de données SQLite
    conn = sqlite3.connect('projet.db')
    cursor = conn.cursor()

    cde_ddl = '''create table if not exists projet(id integer primary key autoincrement,
                code text,description text)'''
    cursor.execute(cde_ddl)
    cursor.execute("INSERT INTO projet (code, description) VALUES (?, ?)", (code_projet, description))
    conn.commit()
    conn.close()

    return jsonify({"message": "Données enregistrées avec succès"})


# Endpoint pour mettre à jour un projet par son numéro
@app.route('/projets/<int:projetId>', methods=['PUT'])
def modifier_projet(projetId):
    try:
        data = request.json
        # Récupérez les données du JSON
        code_projet = data.get('code')
        description = data.get('description')

        # Connectez-vous à la base de données SQLite
        conn = sqlite3.connect('projet.db')
        cursor = conn.cursor()

        cursor.execute('SELECT id FROM projet WHERE id = ?', (projetId,))
        projet_existe = cursor.fetchone()
        if projet_existe is None:
            conn.close()
            return jsonify({"error": "ID de projet non trouvé"}), 404

        # Exécutez la requête SQL de mise à jour en utilisant le numéro de projet
        cursor.execute('UPDATE projet SET code = ?, description = ? WHERE id = ?', (code_projet, description, projetId))
        # Validez la modification
        conn.commit()

        # Fermez la connexion à la base de données
        conn.close()

        return jsonify({"message": "Projet mis à jour avec succès"})
    except Exception as e:
        return jsonify({"error": str(e)})




# Endpoint pour supprimer un projet par son id
@app.route('/projets/<int:projetId>', methods=['DELETE'])
def supprimer_projet(projetId):
        try:
            # Connect to the SQLite database
            conn = sqlite3.connect('projet.db')
            cursor = conn.cursor()
            cursor.execute('SELECT id FROM projet WHERE id = ?', (projetId,))
            projet_existe = cursor.fetchone()
            if projet_existe is None:
                conn.close()
                return jsonify({"error": "ID de projet non trouvé"}), 404

            # Execute the DELETE query using the provided ID
            cursor.execute('DELETE FROM projet WHERE id = ?', (projetId,))

            # Commit the changes and close the database connection
            conn.commit()
            conn.close()

            return jsonify({"message": " Enregistrement supprimé!!"})
        except Exception as e:
            return jsonify({"error": str(e)})

if __name__ == "__main__":
    app.run(debug=True, port=5001)
